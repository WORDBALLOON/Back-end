require("dotenv").config();

module.exports = {
  development: {
    username: "admin",
    password: "wordballoon20",
    database: "wordballoon",
    host: "wordballoon.clr4stjvntrc.ap-northeast-2.rds.amazonaws.com",
    dialect: "mysql",
    operatorsAliases: "false",
  },
  production: {
    username: "admin",
    password: "wordballoon20",
    database: "wordballoon",
    host: "wordballoon.clr4stjvntrc.ap-northeast-2.rds.amazonaws.com",
    dialect: "mysql",
    operatorsAliases: "false",
    logging: false,
  },
};
